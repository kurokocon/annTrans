#!/bin/bash

./fix_id.pl $1 > fixed.gff3
